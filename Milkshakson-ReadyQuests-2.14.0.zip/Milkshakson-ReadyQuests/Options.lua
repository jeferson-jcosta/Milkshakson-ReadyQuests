-- Options panel: Options > AddOns > Milkshakson > Ready Quests
local _, ns = ...
local L = ns.L

function ns:BuildOptions(db)
    local UI = MilkshaksonUI
    if not UI then return end
    local function R() if ns.Refresh then ns.Refresh() end end

    local p = UI:NewPanel("Ready Quests", L.CFG_DESC)

    UI:Section(p, L.CFG_WINDOW)
    UI:Check(p, L.CFG_SHOWN, nil, function() return db.shown end, function(v) db.shown = v; R() end)
    UI:Check(p, L.CFG_AUTOHIDE, L.CFG_AUTOHIDE_TIP, function() return db.autoHide end, function(v) db.autoHide = v; R() end)
    UI:Check(p, L.CFG_LOCKED, L.CFG_LOCKED_TIP, function() return db.locked end, function(v) db.locked = v; R() end)
    UI:Check(p, L.CFG_LOCK_SIZE, L.CFG_LOCK_SIZE_TIP, function() return db.lockSize end, function(v) db.lockSize = v; R() end)
    UI:Slider(p, L.CFG_WIDTH, 220, 800, 10, "%d", function() return db.width end, function(v) db.width = v; R() end)
    UI:Slider(p, L.CFG_MAXH, 70, 1200, 10, "%d", function() return db.maxHeight end, function(v) db.maxHeight = v; R() end)
    UI:Check(p, L.CFG_FIT_HEIGHT, L.CFG_FIT_HEIGHT_TIP, function() return db.fitHeight end, function(v) db.fitHeight = v; R() end)
    UI:Buttons(p, {
        { L.CFG_RESET, function() SlashCmdList.READYQUESTS("reset") end },
    })

    UI:Section(p, L.CFG_LIST)
    UI:Check(p, L.CFG_SHOW_REWARDS, nil, function() return db.showRewards end, function(v) db.showRewards = v; R() end)
    UI:Check(p, L.CFG_SHOW_PLACE, L.CFG_SHOW_PLACE_TIP, function() return db.showPlace end, function(v) db.showPlace = v; R() end)
    UI:Check(p, L.CFG_SHOW_CHAIN, L.CFG_SHOW_CHAIN_TIP, function() return db.showChain end, function(v) db.showChain = v; R() end)
    UI:Check(p, L.CFG_SHOW_KIND, L.CFG_SHOW_KIND_TIP, function() return db.showKind end, function(v) db.showKind = v; R() end)
    UI:Check(p, L.CFG_SHOW_DIST, L.CFG_SHOW_DIST_TIP, function() return db.showDistance end, function(v) db.showDistance = v; R() end)
    UI:Check(p, L.CFG_SHOW_TAXI, L.CFG_SHOW_TAXI_TIP, function() return db.showTaxi end, function(v) db.showTaxi = v; R() end)
    UI:Note(p, L.CFG_UPGRADE)
    UI:Radio(p, {
        { "auto", L.CFG_UP_AUTO }, { "pawn", "Pawn" }, { "gearquest", "GearQuest" }, { "ilvl", L.CFG_UP_ILVL },
    }, function() return db.upgradeSource or "auto" end,
       function(v) db.upgradeSource = v; ns:InvalidateRewards(); R() end)
    UI:Note(p, L.CFG_UPGRADE_NOTE)
    UI:Slider(p, L.CFG_GOLD_MIN, 0, 1000, 10, "%d", function() return db.goldMin or 0 end,
        function(v) db.goldMin = v; ns:InvalidateRewards(); R() end, L.CFG_GOLD_MIN_TIP)

    UI:Section(p, L.CFG_TRACKER)
    UI:Check(p, L.CFG_SHOW_OBJ, nil, function() return db.showObjectives end, function(v) db.showObjectives = v; R() end)
    UI:Check(p, L.CFG_AUTOSWITCH, nil, function() return db.autoSwitch end, function(v) db.autoSwitch = v; R() end)
    UI:Check(p, L.CFG_HIDE_QUESTIE, L.CFG_HIDE_TIP, function() return db.hideQuestie end, function(v) db.hideQuestie = v; R() end)
    UI:Check(p, L.CFG_HIDE_BLIZZ, L.CFG_HIDE_TIP, function() return db.hideBlizzard end, function(v) db.hideBlizzard = v; R() end)
    UI:Check(p, L.CFG_HIDE_QM, L.CFG_HIDE_TIP, function() return db.hideQuestMaster end, function(v) db.hideQuestMaster = v; R() end)
    UI:Check(p, L.CFG_HIDE_EUI, L.CFG_HIDE_TIP, function() return db.hideEllesmere end, function(v) db.hideEllesmere = v; R() end)
    UI:Check(p, L.CFG_AVOID_FDJ, L.CFG_AVOID_FDJ_TIP, function() return db.avoidFDJ end, function(v) db.avoidFDJ = v; R() end)

    UI:Section(p, L.CFG_PARTNERS)
    UI:Check(p, L.CFG_PARTNERS_ON, L.CFG_PARTNERS_TIP, function() return db.partners end,
        function(v) db.partners = v; if ns.PartnersToggled then ns:PartnersToggled() end end)
    UI:Check(p, L.CFG_PARTNERS_WHISPER, L.CFG_PARTNERS_WHISPER_TIP, function() return db.partnersWhisper end,
        function(v) db.partnersWhisper = v end)
    UI:Buttons(p, {
        { L.CFG_DBG_PARTNERS, function() SlashCmdList.READYQUESTS("debug partners") end, L.CFG_DBG_TIP },
    })

    UI:Section(p, L.CFG_ROUTE)
    UI:Buttons(p, {
        { L.ROUTE_BTN, function() SlashCmdList.READYQUESTS("route") end, L.ROUTE_TIP },
        { L.CFG_ROUTE_HERE, function() SlashCmdList.READYQUESTS("route here") end, L.ROUTE_TIP_RIGHT },
    })

    UI:Section(p, L.CFG_DIAG)
    UI:Note(p, L.CFG_DIAG_NOTE)
    UI:Buttons(p, {
        { L.CFG_DBG_GENERAL, function() SlashCmdList.READYQUESTS("debug") end, L.CFG_DBG_TIP },
        { L.CFG_DBG_TAXI, function() SlashCmdList.READYQUESTS("debug taxi") end, L.CFG_DBG_TIP },
        { L.CFG_DBG_KIND, function() SlashCmdList.READYQUESTS("debug kind") end, L.CFG_DBG_TIP },
    })
    UI:Buttons(p, {
        { L.CFG_LIST_CHAT, function() SlashCmdList.READYQUESTS("list") end },
        { L.CFG_HELP_CHAT, function() SlashCmdList.READYQUESTS("help") end },
    })

    UI:Buttons(p, { { L.ABOUT, function() if ns.ShowAbout then ns:ShowAbout() end end }, { L.WHATS_NEW, function() if ns.ShowWhatsNew then ns:ShowWhatsNew(true) end end } })

    UI:Section(p, L.CFG_LOOK)
    UI:Note(p, L.CFG_THEME)
    UI:Radio(p, { { "auto", L.CFG_THEME_AUTO }, { "alliance", L.CFG_THEME_ALLIANCE }, { "horde", L.CFG_THEME_HORDE } },
        function() return db.theme or "auto" end, function(v) db.theme = v; ns.Theme:Apply() end)

    UI:Section(p, L.CFG_LANGUAGE)
    UI:Language(p, ns, db, R, L.CFG_LANG_NOTE)

    UI:Support(p)

    ns.optionsCategory = UI:Register(p, "Ready Quests")
end

function ns:OpenOptions()
    if MilkshaksonUI then MilkshaksonUI:Open(ns.optionsCategory) end
end
